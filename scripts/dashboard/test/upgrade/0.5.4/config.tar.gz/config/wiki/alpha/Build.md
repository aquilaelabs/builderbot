Run make.
